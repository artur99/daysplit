<?php
require_once __DIR__.'/../phpvendor/autoload.php';

$app = new Silex\Application();

include '../app.php';
