<?php

include 'misc.php';
// include 'executers/executers.php';

include 'miscconf.php';
// include 'langs/langconf.php';

include 'user/user_main.php';

include 'mailcls/mail.php';
include 'models/model.php';
include 'routers/routers.php';

// include 'seo/seo_main.php';
