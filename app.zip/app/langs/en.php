<?php
static $lang = [
    'login_email' => 'Email',
    'login_pass' => 'Parola',
    'login_remember' => 'Ține-mă logat',
    'login_bnt' => 'Logare',
    'login_fb' => 'Logare cu Facebook',
    'login_signup' => 'Cont nou',
    'login_reset' => 'Resetare parolă',
];
