<?php

$lang = 'ro';

include $lang.'.php';

// TODO: integrare limbă
// --ro/en/folder?/subdomeniu?


?>
